package com.org.clarivate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;


public class MyHTTPClient {

	public static JsonObject call_me(String url) {
		JsonReader jsonReader = null;
	    JsonObject object = null;
		try {
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			// optional default is GET
			con.setRequestMethod("GET");
			// add request header
			con.setRequestProperty("User-Agent", "Mozilla/5.0");
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			jsonReader = Json.createReader(new StringReader(response.toString()));
			object = jsonReader.readObject();
		} catch (Exception ex) {
			System.out.println("Exeption in call_me : " + ex.getMessage());
		} finally {
			jsonReader.close();
			return object;
		}

	}

}
